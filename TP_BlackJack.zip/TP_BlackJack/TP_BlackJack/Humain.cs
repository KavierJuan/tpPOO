﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_BlackJack
{
    public class Humain : Joueur
    {
        const int MIN_AGE = 18;
        private bool termineJouer;
        private DateTime dateNaissance;

        public bool TermineJouer
        {
            get { return termineJouer; }
            set { termineJouer = value; }
        }

        public DateTime DateNaissance
        {
            get { return dateNaissance; }
            set
            {
                // Validación de la fecha de nacimiento (por ejemplo, debe ser mayor de 18 años).
                DateTime dateActuelle = DateTime.Now;
                int ageMinal = MIN_AGE;
                if (dateActuelle.Year - value.Year < ageMinal)
                {
                    throw new ArgumentException("La date de naissance doit être d'au moins 18 ans.");
                }

                dateNaissance = value;
            }
        }

        public Humain(string nom, string email, DateTime dateNaissance) : base(nom, email)
        {
            TermineJouer = false;
            DateNaissance = dateNaissance;
        }

        public override int CalculerNombreDePoints()
        {
            int total = 0;
            int asCount = 0;

            foreach (Carte carte in Main)
            {
                if (carte.Valeur == 1) // Si es un as
                {
                    asCount++;
                    total += 11; // As inicialmente se cuenta como 11
                }
                else if (carte.Valeur >= 10) // Si es una figura (10, J, Q, K)
                {
                    total += 10;
                }
                else
                {
                    total += carte.Valeur; // Otras cartas
                }
            }

            // Ajuste para los ases
            while (asCount > 0 && total > 21)
            {
                total -= 10; // Cambia el valor del as de 11 a 1 si supera 21
                asCount--;
            }

            // Validación adicional para asegurarse de que el valor total no supere 21
            if (total > 21)
            {
                total = 0; // Si supera 21, se establece en 0 (jugador quemado)
            }

            return total;
        }

        public override void Doubler()
        {
            // Validar si el jugador tiene suficiente dinero para duplicar la apuesta.
            if (Argent >= ValeurMise)
            {
                // Duplicar la apuesta.
                Argent -= ValeurMise; // Restar la apuesta actual del dinero del jugador.
                ValeurMise *= 2; // Duplicar la apuesta.
            }
            else
            {
                // El jugador no tiene suficiente dinero para duplicar la apuesta.
                // Puedes lanzar una excepción, mostrar un mensaje de error o tomar alguna otra acción adecuada.
                throw new InvalidOperationException("Le joueur n'a pas assez d'argent pour doubler la mise.");
            }
        }
    }
}