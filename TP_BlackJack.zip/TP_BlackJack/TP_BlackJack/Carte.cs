﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_BlackJack
{
    public class Carte
    {
        private int valeur;
        private Sorte sorte;
        public int Valeur
        {
            get { return valeur; }
            set
            {
                if (value >= 1 && value <= 13)
                    valeur = value;
                else
                    throw new ArgumentOutOfRangeException("La valeur de la carte doit être comprise entre 1 et 13.");
            }
        }
        public Sorte Sorte
        {
            get { return sorte; }
            set
            {
                if (Enum.IsDefined(typeof(Sorte), value))
                    sorte = value;
                else
                    throw new ArgumentException("La valeur Sorte n'est pas valide.");
            }
        }

        public Carte(int valeur, Sorte sorte)
        {
            this.Valeur = valeur;
            this.Sorte = sorte;
        }


        public string GetNomRessource()
        {
            string valeurNom = "";

            if (Valeur < 1 || Valeur > 13)
            {
                throw new ArgumentOutOfRangeException("La valeur de la carte doit être comprise entre 1 et 13.");
            }

            switch (Valeur)
            {
                case 1:
                    valeurNom = "A";
                    break;
                case 11:
                    valeurNom = "J";
                    break;
                case 12:
                    valeurNom = "Q";
                    break;
                case 13:
                    valeurNom = "K";
                    break;
                default:
                    valeurNom = Valeur.ToString();
                    break;
            }

            string sorteNom = "";
            switch (Sorte)
            {
                case Sorte.Pique:
                    sorteNom = "P";
                    break;
                case Sorte.Carreau:
                    sorteNom = "C";
                    break;
                case Sorte.Coeur:
                    sorteNom = "H";
                    break;
                case Sorte.Trefle:
                    sorteNom = "T";
                    break;
            }

            return $"{valeurNom}{sorteNom}";

        }
    }
}

