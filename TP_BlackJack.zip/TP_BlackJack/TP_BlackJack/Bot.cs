﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_BlackJack
{
    public class Bot : Joueur, IJouer
    {
        public Bot(string nom, string email) : base(nom, email)
        {
        }

        public void Jouer()
        {
            int puntuacion = CalculerNombreDePoints();

            // Paso 1: Verificar la puntuación actual. Si es menor o igual a 16, pedir una carta adicional (Hit).
            if (puntuacion <= 16)
            {
                // Llamar a una función para obtener una nueva carta del mazo y agregarla a la mano (Main).
                //Carte nuevaCarta = ObtenerNuevaCarta();
                //Main.Add(nuevaCarta);

                // Verificar nuevamente la puntuación después de recibir la nueva carta.
                puntuacion = CalculerNombreDePoints();

                // Paso 3: Verificar si la puntuación supera 21. Si es así, el bot se quema (bust).
                if (puntuacion > 21)
                {
                    // Aquí puedes manejar la situación en la que el bot se quema, por ejemplo, registrando una pérdida.
                    Console.WriteLine("El bot se quema.");
                }
            }

            // Paso 4: Si la puntuación es igual o mayor a 17, el bot se planta (Stand).
            if (puntuacion >= 17)
            {
                // Aquí puedes manejar la situación en la que el bot decide plantarse, por ejemplo, no hacer nada y esperar al crupier.
                Console.WriteLine("El bot se planta.");
            }
        }

        public override int CalculerNombreDePoints()
        {
            int total = 0;
            int asCount = 0;

            foreach (Carte carte in Main)
            {
                if (carte.Valeur == 1) // Si es un as
                {
                    asCount++;
                    total += 11; // As inicialmente se cuenta como 11
                }
                else if (carte.Valeur >= 10) // Si es una figura (10, J, Q, K)
                {
                    total += 10;
                }
                else
                {
                    total += carte.Valeur; // Otras cartas
                }
            }

            // Ajuste para los ases
            while (asCount > 0 && total > 21)
            {
                total -= 10; // Cambia el valor del as de 11 a 1 si supera 21
                asCount--;
            }

            // Validación adicional para asegurarse de que el valor total no supere 21
            if (total > 21)
            {
                total = 0; // Si supera 21, se establece en 0 (jugador quemado)
            }

            return total;
        }

        public override void Doubler()
        {
            // Validar si el jugador tiene suficiente dinero para duplicar la apuesta.
            if (Argent >= ValeurMise)
            {
                // Duplicar la apuesta.
                Argent -= ValeurMise; // Restar la apuesta actual del dinero del jugador.
                ValeurMise *= 2; // Duplicar la apuesta.
            }
            else
            {
                // El jugador no tiene suficiente dinero para duplicar la apuesta.
                // Puedes lanzar una excepción, mostrar un mensaje de error o tomar alguna otra acción adecuada.
                throw new InvalidOperationException("Le joueur n'a pas assez d'argent pour doubler la mise.");
            }
        }

        public int GenererMiseAleatoire()
        {
            Random rnd = new Random();
            int miseMin = 10; // Apuesta mínima permitida
            int miseMax = 50; // Apuesta máxima permitida

            // Genera una apuesta aleatoria entre miseMin y miseMax.
            int mise = rnd.Next(miseMin, miseMax + 1);

            // Asegúrate de que el bot tenga suficiente dinero para realizar esta apuesta.
            if (mise > Argent)
            {
                // Si la apuesta es mayor que el dinero disponible, apuesta todo su dinero.
                mise = Argent;
            }

            return mise;
        }
    }
}
