﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using TP_BlackJack;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace TP_BlackJack
{
    public abstract class Joueur : IComparable
    {
        private string nom;
        private string email;
        private int argent;
        private int valeurMise;
        private int positionTable;
        private List<Carte> main = new List<Carte>();

        public string Nom
        {
            get { return nom; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("Le nom ne peut pas être nul");
                nom = value;
            }
        }
        public string Email
        {
            get { return email; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("L'e-mail ne peut pas être nul");

                if (!value.Contains("@"))
                    throw new ArgumentException("L'e-mail doit contenir @");

                email = value;
            }
        }
        public int Argent
        {
            get { return argent; }
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException("L'argent ne peut pas être négatif");
                argent = value;
            }
        }
        public int ValeurMise
        {
            get { return valeurMise; }
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException("Le valeur Mise ne peut pas être négatif");
                valeurMise = value;
            }
        }
        public int PositionTable
        {
            get { return positionTable; }
            set
            {
                if (value < 0)
                    throw new ArgumentOutOfRangeException("La position du tableau ne peut pas être négative");
                positionTable = value;
            }
        }
        public List<Carte> Main
        {
            get { return main; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("La main ne peut pas être nulle");
                main = value;
            }
        }

        public Joueur(string nom, string email)
        {
            this.Nom = nom;
            this.Email = email;
            this.Argent = 100;
            this.ValeurMise = 0;
            this.Main = new List<Carte>();
        }

        public virtual int CalculerNombreDePoints()
        {
            int total = 0;
            int asCount = 0;

            foreach (Carte carte in Main)
            {
                if (carte.Valeur == 1) // Si es un as
                {
                    asCount++;
                    total += 11; // As inicialmente se cuenta como 11
                }
                else if (carte.Valeur >= 10) // Si es una figura (10, J, Q, K)
                {
                    total += 10;
                }
                else
                {
                    total += carte.Valeur; // Otras cartas
                }
            }

            // Ajuste para los ases
            while (asCount > 0 && total > 21)
            {
                total -= 10; // Cambia el valor del as de 11 a 1 si supera 21
                asCount--;
            }

            // Validación adicional para asegurarse de que el valor total no supere 21
            if (total > 21)
            {
                total = 0; // Si supera 21, se establece en 0 (jugador quemado)
            }

            return total;
        }

        public virtual void Doubler()
        {
            // Validar si el jugador tiene suficiente dinero para duplicar la apuesta.
            if (Argent >= ValeurMise)
            {
                // Duplicar la apuesta.
                Argent -= ValeurMise; // Restar la apuesta actual del dinero del jugador.
                ValeurMise *= 2; // Duplicar la apuesta.
            }
            else
            {
                // El jugador no tiene suficiente dinero para duplicar la apuesta.
                // Puedes lanzar una excepción, mostrar un mensaje de error o tomar alguna otra acción adecuada.
                throw new InvalidOperationException("Le joueur n'a pas assez d'argent pour doubler la mise.");
            }
        }

        public override string ToString()
        {
            // Implementa la lógica para convertir el jugador en una cadena.
            return $"Nom: {Nom}, Email: {Email}, Argent: {Argent}, Mise: {ValeurMise}, Main: {string.Join(", ", Main)}";
        }

        public int CompareTo(object obj)
        {
            if (obj == null)
                return 1; // El objeto no puede ser nulo, por lo que el objeto actual es mayor.

            if (!(obj is Joueur otherPlayer))
                throw new ArgumentException("L'objet n'est pas un joueur", nameof(obj));

            // Manejo de nombres nulos
            if (this.Nom == null && otherPlayer.Nom == null)
                return 0; // Ambos nombres son nulos, considerarlos iguales.
            else if (this.Nom == null)
                return -1; // El nombre del jugador actual es nulo, considerarlo menor.
            else if (otherPlayer.Nom == null)
                return 1; // El nombre del otro jugador es nulo, considerarlo mayor.

            return this.Nom.CompareTo(otherPlayer.Nom);
        }
    }
}
