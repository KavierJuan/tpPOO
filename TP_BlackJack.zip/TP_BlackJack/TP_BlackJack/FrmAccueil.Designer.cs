﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TP_BlackJack
{
    partial class FrmAccueil
    {
        const int AGE_MINIMUM = 18;
        const int NOMBRE_MAX_JOUEURS = 4;
        const int NOMBRE_MIN_BOTS = 1;
        const int NOMBRE_MAX_BOTS = 3;
        const string DATETIME_MIN_VALUE = "01/01/1923";

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <paramname="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtEmail = new TextBox();
            txtNom = new TextBox();
            dtpNaissance = new DateTimePicker();
            lstJoueurs = new ListBox();
            btnDemarrer = new Button();
            lblCommencer = new Label();
            llbInstruction1 = new Label();
            lblInstruction2 = new Label();
            lblInstruction3 = new Label();
            lblNom = new Label();
            lblEmail = new Label();
            labelDateNaissance = new Label();
            lbllesJoueurs = new Label();
            lbllstJoueurs = new Label();
            lblajoutJoueurs = new Label();
            numBots = new NumericUpDown();
            btnajoutJoueur = new Button();
            lblnbrBot = new Label();
            ((System.ComponentModel.ISupportInitialize)numBots).BeginInit();
            SuspendLayout();
            // 
            // txtEmail
            // 
            txtEmail.Location = new System.Drawing.Point(352, 181);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new System.Drawing.Size(196, 23);
            txtEmail.TabIndex = 0;
            // 
            // txtNom
            // 
            txtNom.Location = new System.Drawing.Point(352, 217);
            txtNom.Name = "txtNom";
            txtNom.Size = new System.Drawing.Size(196, 23);
            txtNom.TabIndex = 1;
            // 
            // dtpNaissance
            // 
            dtpNaissance.Location = new System.Drawing.Point(419, 252);
            dtpNaissance.Name = "dtpNaissance";
            dtpNaissance.Size = new System.Drawing.Size(129, 23);
            dtpNaissance.TabIndex = 3;
            // 
            // lstJoueurs
            // 
            lstJoueurs.ItemHeight = 15;
            lstJoueurs.Location = new System.Drawing.Point(83, 181);
            lstJoueurs.Name = "lstJoueurs";
            lstJoueurs.Size = new System.Drawing.Size(185, 94);
            lstJoueurs.TabIndex = 4;
            lstJoueurs.SelectedIndexChanged += lstJoueurs_SelectedIndexChanged;
            // 
            // btnDemarrer
            // 
            btnDemarrer.Location = new System.Drawing.Point(307, 331);
            btnDemarrer.Name = "btnDemarrer";
            btnDemarrer.Size = new System.Drawing.Size(241, 50);
            btnDemarrer.TabIndex = 5;
            btnDemarrer.Text = "Commencer la partie";
            btnDemarrer.Click += btnDemarrer_Click;
            // 
            // lblCommencer
            // 
            lblCommencer.Location = new System.Drawing.Point(197, 16);
            lblCommencer.Name = "lblCommencer";
            lblCommencer.Size = new System.Drawing.Size(310, 30);
            lblCommencer.TabIndex = 6;
            lblCommencer.Text = "Jeu de Blackjack Instructions";
            // 
            // llbInstruction1
            // 
            llbInstruction1.AutoSize = true;
            llbInstruction1.Location = new System.Drawing.Point(124, 53);
            llbInstruction1.Name = "llbInstruction1";
            llbInstruction1.Size = new System.Drawing.Size(427, 15);
            llbInstruction1.TabIndex = 7;
            llbInstruction1.Text = "1- Une partie peut contenir 1 à 4 joueurs (Création possible de joueur au besoin)";
            // 
            // lblInstruction2
            // 
            lblInstruction2.AutoSize = true;
            lblInstruction2.Location = new System.Drawing.Point(130, 78);
            lblInstruction2.Name = "lblInstruction2";
            lblInstruction2.Size = new System.Drawing.Size(315, 15);
            lblInstruction2.TabIndex = 8;
            lblInstruction2.Text = "2- Sélectionnez votre joueur et inscrire le nombre de bot(s)";
            // 
            // lblInstruction3
            // 
            lblInstruction3.AutoSize = true;
            lblInstruction3.Location = new System.Drawing.Point(124, 103);
            lblInstruction3.Name = "lblInstruction3";
            lblInstruction3.Size = new System.Drawing.Size(109, 15);
            lblInstruction3.TabIndex = 9;
            lblInstruction3.Text = "3- Débutez la partie";
            // 
            // lblNom
            // 
            lblNom.AutoSize = true;
            lblNom.Location = new System.Drawing.Point(307, 225);
            lblNom.Name = "lblNom";
            lblNom.Size = new System.Drawing.Size(37, 15);
            lblNom.TabIndex = 10;
            lblNom.Text = "Nom:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new System.Drawing.Point(305, 189);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new System.Drawing.Size(39, 15);
            lblEmail.TabIndex = 11;
            lblEmail.Text = "Email:";
            // 
            // labelDateNaissance
            // 
            labelDateNaissance.AutoSize = true;
            labelDateNaissance.Location = new System.Drawing.Point(307, 258);
            labelDateNaissance.Name = "labelDateNaissance";
            labelDateNaissance.Size = new System.Drawing.Size(106, 15);
            labelDateNaissance.TabIndex = 12;
            labelDateNaissance.Text = "Date de Naissance:";
            // 
            // lbllesJoueurs
            // 
            lbllesJoueurs.AutoSize = true;
            lbllesJoueurs.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            lbllesJoueurs.Location = new System.Drawing.Point(280, 116);
            lbllesJoueurs.Name = "lbllesJoueurs";
            lbllesJoueurs.Size = new System.Drawing.Size(112, 25);
            lbllesJoueurs.TabIndex = 13;
            lbllesJoueurs.Text = "Les joueurs";
            // 
            // lbllstJoueurs
            // 
            lbllstJoueurs.AutoSize = true;
            lbllstJoueurs.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lbllstJoueurs.Location = new System.Drawing.Point(130, 147);
            lbllstJoueurs.Name = "lbllstJoueurs";
            lbllstJoueurs.Size = new System.Drawing.Size(105, 21);
            lbllstJoueurs.TabIndex = 14;
            lbllstJoueurs.Text = "Votre joueur";
            // 
            // lblajoutJoueurs
            // 
            lblajoutJoueurs.AutoSize = true;
            lblajoutJoueurs.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblajoutJoueurs.Location = new System.Drawing.Point(335, 147);
            lblajoutJoueurs.Name = "lblajoutJoueurs";
            lblajoutJoueurs.Size = new System.Drawing.Size(216, 21);
            lblajoutJoueurs.TabIndex = 15;
            lblajoutJoueurs.Text = "Ajouter un nouveau joueur";
            // 
            // numBots
            // 
            numBots.Location = new System.Drawing.Point(485, 292);
            numBots.Maximum = new decimal(new int[] { 3, 0, 0, 0 });
            numBots.Name = "numBots";
            numBots.Size = new System.Drawing.Size(66, 23);
            numBots.TabIndex = 16;
            // 
            // btnajoutJoueur
            // 
            btnajoutJoueur.Location = new System.Drawing.Point(582, 234);
            btnajoutJoueur.Name = "btnajoutJoueur";
            btnajoutJoueur.Size = new System.Drawing.Size(85, 29);
            btnajoutJoueur.TabIndex = 17;
            btnajoutJoueur.Text = "Ajouter";
            btnajoutJoueur.Click += btnajoutJoueur_Click;
            // 
            // lblnbrBot
            // 
            lblnbrBot.AutoSize = true;
            lblnbrBot.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblnbrBot.Location = new System.Drawing.Point(307, 294);
            lblnbrBot.Name = "lblnbrBot";
            lblnbrBot.Size = new System.Drawing.Size(145, 21);
            lblnbrBot.TabIndex = 18;
            lblnbrBot.Text = "Nombre de bot(s)";
            // 
            // FrmAccueil
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(800, 450);
            Controls.Add(lblnbrBot);
            Controls.Add(btnajoutJoueur);
            Controls.Add(lblajoutJoueurs);
            Controls.Add(lbllstJoueurs);
            Controls.Add(lbllesJoueurs);
            Controls.Add(labelDateNaissance);
            Controls.Add(lblEmail);
            Controls.Add(lblNom);
            Controls.Add(lblInstruction3);
            Controls.Add(lblInstruction2);
            Controls.Add(llbInstruction1);
            Controls.Add(lblCommencer);
            Controls.Add(txtEmail);
            Controls.Add(txtNom);
            Controls.Add(dtpNaissance);
            Controls.Add(lstJoueurs);
            Controls.Add(btnDemarrer);
            Controls.Add(numBots);
            Name = "FrmAccueil";
            Text = "Accueil";
            Load += FrmAccueil_Load;
            ((System.ComponentModel.ISupportInitialize)numBots).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void btnajoutJoueur_Click(object sender, EventArgs e)
        {
            if (!EstEmailValide(txtEmail.Text))
            {
                AfficherMessage("Veuillez entrer une adresse e-mail valide.");
                return;
            }

            if (EstVide(txtNom.Text))
            {
                AfficherMessage("Le prénom est obligatoire.");
                return;
            }

            if (!EstMajeur(dtpNaissance.Value))
            {
                AfficherMessage("Vous devez avoir au moins 18 ans pour jouer.");
                return;
            }

            if (lstJoueurs.Items.Count > NOMBRE_MAX_JOUEURS)
            {
                AfficherMessage("Vous ne pouvez pas ajouter plus de 4 joueurs.");
                return;
            }

            var joueur = new Humain(txtNom.Text, txtEmail.Text, dtpNaissance.Value);
            lstJoueurs.Items.Add(joueur);

            txtEmail.Text = "";
            txtNom.Text = "";
            dtpNaissance.Value = DateTime.Parse(DATETIME_MIN_VALUE);

            if (lstJoueurs.Items.Count == NOMBRE_MAX_JOUEURS)
            {
                btnajoutJoueur.Enabled = false;
            }
        }

        private void btnDemarrer_Click(object sender, EventArgs e)
        {
            if (!EstJoueurHumainSelectionne(lstJoueurs))
            {
                AfficherMessage("Veuillez sélectionner un joueur.");
                return;
            }

            if (numBots.Value == 0)
            {
                AfficherMessage("Veuillez sélectionner au moins un bot.");
                return;
            }
        }

        private void lstJoueurs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstJoueurs.SelectedItem is Humain joueur)
            {
                txtNom.Text = joueur.Nom;
                txtEmail.Text = joueur.Email;
                dtpNaissance.Value = joueur.DateNaissance;
            }

            if (lstJoueurs.SelectedItem is null)
            {
                txtNom.Text = "Hard Code";
                txtEmail.Text = "";
                dtpNaissance.Value = DateTime.MinValue;
            }
        }
        #endregion

        private TextBox txtEmail;
        private TextBox txtNom;
        private DateTimePicker dtpNaissance;
        private ListBox lstJoueurs;
        private Button btnDemarrer;
        private Label lblCommencer;
        private Label llbInstruction1;
        private Label lblInstruction2;
        private Label lblInstruction3;
        private Label lblNom;
        private Label lblEmail;
        private Label labelDateNaissance;
        private Label lbllesJoueurs;
        private Label lbllstJoueurs;
        private Label lblajoutJoueurs;
        private NumericUpDown numBots;
        private Button btnajoutJoueur;
        private Label lblnbrBot;


        private bool EstMajeur(DateTime dateNaissance)
        {
            return DateTime.Now.Year - dateNaissance.Year >= AGE_MINIMUM;
        }

        private bool EstEmailValide(string email)
        {
            return email.Contains("@");
        }

        private bool EstVide(string texte)
        {
            return string.IsNullOrWhiteSpace(texte);
        }

        private bool EstJoueurHumainSelectionne(ListBox liste)
        {
            return liste.SelectedIndex != -1;
        }

        private void AfficherMessage(string message)
        {
            MessageBox.Show(message);
        }
    }
}


