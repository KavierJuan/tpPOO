﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TP_BlackJack
{
    public static class Utilitaire
    {
        public static bool ValiderChaineObligatoire(string chaine)
        {
            return !string.IsNullOrWhiteSpace(chaine);
        }

        public static bool ValiderEmail(string chaine)
        {
            return Regex.IsMatch(chaine, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$");
        }

        public static void MelangerNombres(int[] arreglo)
        {
            Random rnd = new Random();
            int n = arreglo.Length;

            for (int i = 0; i < n - 1; i++)
            {
                int j = rnd.Next(i, n); // Generar un índice aleatorio entre i y n-1

                // Intercambiar el elemento en la posición i con el elemento en la posición j
                int temp = arreglo[i];
                arreglo[i] = arreglo[j];
                arreglo[j] = temp;
            }
        }

        public static List<int> GenererSequence(int premierValeur, int dernierValeur)
        {
            if (premierValeur > dernierValeur)
            {
                throw new ArgumentException("Le premier nombre doit être inférieur ou égal au dernier nombre.");
            }

            List<int> sequence = new List<int>();

            for (int i = premierValeur; i <= dernierValeur; i++)
            {
                sequence.Add(i);
            }

            return sequence;
        }
    }
}
