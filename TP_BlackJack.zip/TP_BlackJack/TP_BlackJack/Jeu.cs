﻿using System;
using System.Collections.Generic;
using System.Linq;
using TP_BlackJack;

public static class Jeu
{
    const int MAX_CARTES_EN_MAIN = 5;
    const int MAX_CARTES_EN_PAQUET = 52;

    private static List<Carte> paquetCartes;
    private static List<Joueur> joueurs;
    private static Dealer dealer;
    private static Random random;

    public static List<Carte> PaquetCartes
    {
        get { return paquetCartes; }
        set
        {
            if (value == null)
                throw new ArgumentNullException();

            paquetCartes = value;
        }
    }

    public static List<Joueur> Joueurs
    {
        get { return joueurs; }
        set
        {
            if (value == null)
                throw new ArgumentNullException();

            joueurs = value;
        }
    }

    public static Dealer Dealer
    {
        get { return dealer; }
        set
        {
            if (value == null)
                throw new ArgumentNullException();

            dealer = value;
        }
    }
    public static Random Rnd
    {
        get { return random; }
    }

    public static void PigerUneCarteJoueur(Joueur joueur)
    {
        {
            if (PaquetCartes.Count == 0)
            {
                throw new InvalidOperationException("Le paquet de cartes est vide. La partie doit être réinitialisée.");
            }

            if (joueur.Main.Count >= MAX_CARTES_EN_MAIN)
            {
                throw new InvalidOperationException("Le joueur a déjà atteint le nombre maximum de cartes en main.");
            }

            Carte carteTiree = PaquetCartes[0];
            PaquetCartes.RemoveAt(0);
            joueur.Main.Add(carteTiree);
        }
    }

    public static void PigerUneCarteDealer(Dealer dealer)
    {
        if (PaquetCartes.Count == 0)
        {
            throw new InvalidOperationException("Le paquet de cartes est vide. La partie doit être réinitialisée.");
        }

        if (dealer.Main.Count >= MAX_CARTES_EN_MAIN)
        {
            throw new InvalidOperationException("Le croupier a déjà atteint le nombre maximum de cartes en main.");
        }

        Carte carteTiree = PaquetCartes[0];
        PaquetCartes.RemoveAt(0);
        dealer.Main.Add(carteTiree);
    }

    public static List<Carte> CreerPaquetCartes()
    {
        List<Carte> paquetCartes = new List<Carte>();

        foreach (Sorte sorte in Enum.GetValues(typeof(Sorte)))
        {
            for (int valeur = 2; valeur <= 11; valeur++) // Cambiar el límite superior a 11 para cartas numéricas y as.
            {
                Carte carte = new Carte(valeur, sorte);
                paquetCartes.Add(carte);
            }

            // Agregar las figuras (Rey, Reina y Jota) con un valor de 10.
            for (int i = 0; i < 3; i++)
            {
                Carte figure = new Carte(10, sorte);
                paquetCartes.Add(figure);
            }
        }

        // Créez ou fournissez un clone du paquet de cartes.
        return paquetCartes;
    }

    public static void InitialiserPaquetCartes()
    {
        PaquetCartes = CreerPaquetCartes();
        BrasserCartes();
    }

    // Lugar adecuado para llamar a InitialiserPaquetCartes cuando sea necesario.

    public static void BrasserCartes()
    {
        if (PaquetCartes == null)
        {
            throw new InvalidOperationException("Le paquet de cartes est nul. Assurez-vous de l'initialiser correctement.");
        }

        // Verificar si hay elementos nulos en la lista de cartas.
        if (PaquetCartes.Any(carte => carte == null))
        {
            throw new InvalidOperationException("Le paquet de cartes contient des cartes nulles. Assurez-vous de remplir le paquet correctement.");
        }

        int n = PaquetCartes.Count;
        while (n > 1)
        {
            n--;
            int k = random.Next(n + 1);
            Carte temp = PaquetCartes[k];
            PaquetCartes[k] = PaquetCartes[n];
            PaquetCartes[n] = temp;
        }
    }

    public static void DistribuerLesCartes()
    {
        // Verificar si ya se distribuyeron cartas
        if (Joueurs.Any(joueur => joueur.Main.Any()) || Dealer.Main.Any())
        {
            throw new InvalidOperationException("Les cartes ont déjà été distribuées.");
        }

        // Verificar si hay suficientes jugadores
        if (Joueurs.Count < 2)
        {
            throw new InvalidOperationException("Il n'y a pas suffisamment de joueurs pour commencer la partie.");
        }

        // Verificar si hay suficientes cartas en el paquete
        if (PaquetCartes.Count < (Joueurs.Count + 1) * 2)
        {
            // No hay suficientes cartas para distribuir, reiniciar el juego o mezclar cartas nuevamente.
            RecommencerPartie(); // Implementa la lógica para reiniciar una partida.
        }

        foreach (Joueur joueur in Joueurs)
        {
            PigerUneCarteJoueur(joueur);
            PigerUneCarteJoueur(joueur);
        }

        // Pour simuler une carte du croupier face cachée, vous pouvez simplement ne pas montrer la première carte dans la vue du joueur.
        PigerUneCarteDealer(Dealer);
        PigerUneCarteDealer(Dealer);
    }

    public static void RecommencerPartie()
    {
        // Verificar si hay suficientes jugadores
        if (Joueurs.Count == 0)
        {
            throw new InvalidOperationException("Aucun joueur n'est présent pour recommencer la partie.");
        }

        // Verifica si el paquete de cartas está vacío antes de crear uno nuevo y barajarlo.
        if (PaquetCartes.Count == 0)
        {
            PaquetCartes = CreerPaquetCartes();
            BrasserCartes();
        }

        // Verificar si el crupier tiene al menos una carta
        if (dealer.Main.Count == 0)
        {
            throw new InvalidOperationException("Le croupier n'a pas de cartes pour commencer la partie.");
        }

        ReinitialiserLesMains();
    }

    public static void ReinitialiserLesMains()
    {
        foreach (Joueur joueur in Joueurs)
        {
            joueur.Main.Clear();
        }

        if (Dealer != null && Dealer.Main != null)
        {
            Dealer.Main.Clear();
        }
    }

    public static Joueur AjouterUnBotAleatoirement(List<Joueur> listeJoueursLibres)
    {
        // Verificar si la lista de jugadores libres no es nula y si hay al menos un jugador libre.
        if (listeJoueursLibres != null && listeJoueursLibres.Count > 0)
        {
            // Verificar si la cantidad total de jugadores (incluyendo el bot) no supera el límite permitido.
            if (Joueurs.Count < 4)
            {
                string nomBot = "Bot " + (Joueurs.Count + 1);
                string emailBot = "bot" + (Joueurs.Count + 1) + "@exemple.com";
                Bot bot = new Bot(nomBot, emailBot);
                Joueurs.Add(bot);
                return bot;
            }
        }
        return null; // No se pudo agregar un bot aleatorio.
    }

    public static int ObtenirUnePositionAleatoire()
    {
        int positionAleatoire;
        List<int> positionsOcupadas = Joueurs.Select(joueur => joueur.PositionTable).ToList();

        // Generar una posición aleatoria hasta encontrar una posición no ocupada
        do
        {
            positionAleatoire = random.Next(4); // Suponiendo que hay 5 posiciones en la mesa
        } while (positionsOcupadas.Contains(positionAleatoire));

        return positionAleatoire;
    }

    public static List<int> ObtenirPositionLibres()
    {
        List<int> positionsLibres = new List<int>();

        // Verificar si la lista de jugadores no es nula
        if (Joueurs != null)
        {
            // Verificar si el número de posiciones en la mesa es igual a 5
            if (Joueurs.Count == 4)
            {
                for (int i = 0; i < 4; i++)
                {
                    bool positionOccupee = false;
                    foreach (Joueur joueur in Joueurs)
                    {
                        // Verificar que la posición del jugador sea válida (0 a 4)
                        if (joueur.PositionTable == i)
                        {
                            positionOccupee = true;
                            break;
                        }
                    }
                    if (!positionOccupee)
                    {
                        positionsLibres.Add(i);
                    }
                }
            }
            else
            {
                throw new InvalidOperationException("Le nombre total de positions dans la table doit être de 5.");
            }
        }
        else
        {
            throw new ArgumentNullException("La liste des joueurs ne peut pas être nulle.");
        }

        return positionsLibres;
    }
}

