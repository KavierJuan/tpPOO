﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_BlackJack
{
    public class Dealer : IJouer
    {
        private bool plusQue21;
        private List<Carte> main;
        public bool PlusQue21
        {
            get { return plusQue21; }
            set { plusQue21 = value; }
        }

        public List<Carte> Main
        {
            get { return main; }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("La liste de cartes de la main ne peut pas être nulle");
                }
                main = value;
            }
        }

        public Dealer()
        {
            PlusQue21 = false;
            Main = new List<Carte>();
        }

        public void Jouer()
        {
            if (Main == null)
            {
                throw new InvalidOperationException("La liste des cartes du croupier est nulle.");
            }

            if (Main.Count == 0)
            {
                Console.WriteLine("La main du croupier est vide.");
                return;
            }

            foreach (Carte card in Main)
            {
                if (card == null)
                {
                    throw new InvalidOperationException("La main du croupier contient une carte nulle.");
                }
            }

            Console.WriteLine("Au tour du croupier");
            while (CalculaerNombreDePoints() < 17)
            {
                //Console.WriteLine("Dealer hits");
                Console.WriteLine($"Main du croupier : {Main.Count} cartes");
                foreach (Carte card in main)
                {
                    Console.WriteLine(card.GetNomRessource());
                }
            }
            if (CalculaerNombreDePoints() > 21)
            {
                Console.WriteLine("croupier bustes");
                plusQue21 = true;
            }
            else
            {
                Console.WriteLine("croupier stands");
            }
        }

        public int CalculaerNombreDePoints()
        {
            int points = 0;
            int nombreAS = 0;

            if (main == null)
            {
                throw new InvalidOperationException("La liste des cartes du croupier est nulle.");
            }


            foreach (Carte card in main)
            {
                if (card.Valeur == 1)
                {
                    nombreAS++;
                }
                else if (card.Valeur > 10)
                {
                    points += 10;
                }
                else
                {
                    points += card.Valeur;
                }
            }
            for (int i = 0; i < nombreAS; i++)
            {
                if (points + 11 > 21)
                {
                    points += 1;
                }
                else
                {
                    points += 11;
                }
            }
            return points;
        }
    }
}
